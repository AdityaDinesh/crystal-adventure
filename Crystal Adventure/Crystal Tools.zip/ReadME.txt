Inside the Tools Project :-

* Just click on file ->load and select the file to load {There is a map.json file under the Data folder}

* Then click load rooms to load the respective room from the dropdown

* The data for the Analytics Tool is alos there in the Data folder with the name "crystal.db"